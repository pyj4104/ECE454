#!/bin/sh
user=h53huang
hdfs dfs -cat /user/$user/output/*

