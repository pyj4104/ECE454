package ece454750s15a1;

public class FEServer
{
	public static void main(String[] args)
	{
		FEServerBody frontEnd;

		frontEnd = new FEServerBody(args);
	}
}
