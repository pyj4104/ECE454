package ece454750s15a1;

public class BEServer
{
	public static void main(String[] args)
	{
		BEServerBody backEnd;

		backEnd = new BEServerBody(args);
	}
}
